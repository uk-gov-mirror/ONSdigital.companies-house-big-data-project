class BinaryClassiferMetrics:
    '''
    '''
    def binary_confusion_matrix():
    '''
    '''
        pass
        
    def accuracy():
    '''
    '''
        pass
        
    def precision():
    '''
    '''
        pass
    
    def area_under_the_curve():
    '''
    '''
        pass
    
    def metrics_reports():
    '''
    '''
        pass
